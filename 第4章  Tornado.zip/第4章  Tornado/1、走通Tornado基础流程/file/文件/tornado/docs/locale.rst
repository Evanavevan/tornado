``tornado.locale`` --- Internationalization support
===================================================

.. automodule:: tornado.locale
   :members:
