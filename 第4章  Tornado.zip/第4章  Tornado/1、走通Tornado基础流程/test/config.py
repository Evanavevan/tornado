
# 参数
options = {
    "port": 8080,
    "list": ["good","nice","handsome"]
}


# 配置

