from ORM.orm import ORM

'''
class ClassName(ORM):
    def __init__(self):
        pass
'''


